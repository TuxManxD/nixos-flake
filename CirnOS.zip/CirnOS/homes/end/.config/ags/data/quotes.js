export const quotes = [
    {
        quote: 'Nvidia, fuck you',
        author: 'Linus Torvalds',
    },
    {
        quote: 'reproducible system? cock and vagina?',
        author: 'vaxry',
    },
    {
        quote: "haha pointers hee hee i love pointe-\\\nProcess Vaxry exited with signal SIGSEGV",
        author: 'vaxry',
    }
];
